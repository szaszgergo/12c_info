<?php
session_start();
require_once 'vendor/autoload.php';
use Dompdf\Dompdf;

$errors = [];

$name = $_POST['name'];
$birthnum = $_POST['birthYear'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$workplace = $_POST['workplace'];
$workpos = $_POST['position'];
$uploaded_img = $_FILES['image'];
$correct_recap = $_POST['correct_captcha'];
$user_recap = $_POST['captcha'];
$date = date("Y-m-d h:i:s");


// Check captcha
if ($user_recap != $correct_recap) {
    $errors[] = "Helytelen captcha.";
}

// Function to check if a string is a valid email address
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Check if the uploaded file encountered an error
if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $uploadError = $_FILES['image']['error'];
    $uploadErrorMessage = '';

    switch ($uploadError) {
        case UPLOAD_ERR_FORM_SIZE:
            $uploadErrorMessage = 'A feltöltött fájl meghaladja a HTML űrlapban megadott MAX_FILE_SIZE irányelvet.';
            break;
        case UPLOAD_ERR_NO_FILE:
            $uploadErrorMessage = 'Nem let feltöltve fájl.';
            break;
        case UPLOAD_ERR_EXTENSION:
            $uploadErrorMessage = 'A fájl feltöltését egy PHP kiterjesztés megállította.';
            break;
        default:
            $uploadErrorMessage = 'Ismeretlen felöltési hiba.';
            break;
    }
    $errors[] = "Hiba: $uploadErrorMessage";
}

// Check if the uploaded file is an image
if (!empty($_FILES['image']['tmp_name']) && !getimagesize($_FILES['image']['tmp_name'])) {
    $errors[] = "Hiba: A feltöltött fájl nem kép.";
}

// Check if email is valid
if (!isValidEmail($email)) {
    $errors[] = "Hiba: Helytelen email cím.";
}

// Check if email is already registered
if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $filename = "jelentkezok/" . $email . ".txt";
    
    if (file_exists($filename)) {
        $errors[] = "Ezzel az e-mail címmel már jelentkeztek.";
    }
}

// Function to resize image to specified dimensions without maintaining aspect ratio
function resizeImage($imagePath, $newWidth, $newHeight, $resizedImagePath) {
    // Open original image
    $originalImage = imagecreatefromstring(file_get_contents($imagePath));

    // Create a blank canvas with the new dimensions
    $resizedImage = imagecreatetruecolor($newWidth, $newHeight);

    // Resize the image to the new dimensions
    imagecopyresampled($resizedImage, $originalImage, 0, 0, 0, 0, $newWidth, $newHeight, imagesx($originalImage), imagesy($originalImage));

    // Save the resized image to a new file path
    imagejpeg($resizedImage, $resizedImagePath, 100);

    // Free up memory
    imagedestroy($resizedImage);
    imagedestroy($originalImage);
}

if (empty($errors)) {
    $originalImagePath = $_FILES["image"]["tmp_name"];
    list($width, $height) = getimagesize($originalImagePath);

    if ($width < 480 || $height < 480) {
        $errors[] = "<p style='color: red;'>A kép mérete legalább 480x480 pixel kell legyen.</p>";
    } else {
        $newWidth = $width;
        $newHeight = $height;

        if ($width > 640 || $height > 640) {
            $newWidth = 640;
            $newHeight = 640;
        } elseif ($width > 480 && $width < 640 && $height > 480 && $height < 640) {
            $newWidth = min($width, $height);
            $newHeight = $newWidth;
        }


        function getClientIP() {
            $ipAddress = '';
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                $ipAddress = explode(',', $ipAddress)[0];
            } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
                $ipAddress = $_SERVER['REMOTE_ADDR'];
            }
            return $ipAddress;
        }

        $clientIP = getClientIP();


        /*
        $to = "$email";
        $subject = "Belépőkártya letöltése";
        $pdf_url = "https://www.example.com/belépőkártya.pdf";
        $message = "Kedves Jelentkező,\n\nKérjük, kattintson az alábbi linkre a belépőkártya letöltéséhez:\n\n";
        $message .= $pdf_url . "\n\n";
        $message .= "Üdvözlettel,\n A Szervezők";
        $headers = "From: szasz.gergo@wm-iskola.hu";
        */


        // Ensure the emailcim and file_extension variables are set properly
        $emailcim = $email;
        $file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

        $file_name = $emailcim . "_image." . $file_extension;
        $target_file = "jelentkezok/" . $file_name;

        resizeImage($originalImagePath, $newWidth, $newHeight, $target_file);

        if (file_exists($target_file)) {
            //////pdf

            $dompdf = new Dompdf([
                 "chroot" => __DIR__
            ]);

            // HTML content for the card
            $html = '
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>SEO Konferencia</title>
                <style>
                    body {
                        font-family: Arial,
                        sans-serif;
                        font: size 12px;
                    }
                    .card {
                        width: 90mm;
                        height: 55mm;
                        border: 1px solid #ccc;
                        padding: 10px;
                        box-sizing: border-box;
                    }
                    .profile-img {
                        width: 83px;
                        height: 83px;
                        border-radius: 50%;
                        margin-right: 10px;
                        float:left;
                    }
                    h1{
                        font: size 18px;
                    }
                    .toright{
                        margin-left:90px ;
                    }
                </style>
            </head>
            <body>
                <div class="card">
                    <h1>SEO Konferencia</h1>
                    <p>Rendezvény dátuma:2025.01.15 9:00</p>
                    <div style="display: flex; align-items: center;">
                        <img src="jelentkezok/' . $file_name . '" class="profile-img" alt="Profile Image">
                        <div class="toright">
                            <p><strong>' . $name . '</strong></p>
                            <p>' . $workplace . '</p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
            ';

            // Load HTML content into dompdf
            $dompdf->loadHtml($html);

            // (Optional) Set paper size and orientation
            $dompdf->setPaper('A5', 'portrait');

            // Render the HTML as PDF
            $dompdf->render();

            // Output the generated PDF
            $pdf_content = $dompdf->output();

            // Save PDF to a file
            $pdf_filename = $email . '.pdf';
            $pdf_path = 'jelentkezok/' . $pdf_filename;
            file_put_contents($pdf_path, $pdf_content);



            /////////
            $fp = fopen("jelentkezok/$emailcim.txt", "a");
            $adatok = "$name;$birthnum;$email;$phone;$workplace;$workpos;$file_name;$date;$clientIP";
            fwrite($fp, $adatok);
            fclose($fp);
            header("Location: success.html");
            exit();
        } else {
            $errors[] = "Sajnáljuk, hiba történt a feltöltés során.";
        }
    }
}

if (!empty($errors)) {
    $_SESSION['errors'] = $errors;
    header("Location: index.php");
    exit();
}
?>
