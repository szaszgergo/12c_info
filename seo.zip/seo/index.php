<?php
session_start();

$num1 = rand(1, 10);
$num2 = rand(1, 10);
$sum = $num1 + $num2;

$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : [];
unset($_SESSION['errors']);

///////
$root = 'C:/xampp/htdocs/seo/jelentkezok/';
$reg_file = glob($root . "*.txt");
$count_reg = count($reg_file);

if ($count_reg > 4) {
    header("Location: full.html");
    exit();
}

//////
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seo konferencia</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="form-container">
        <h2>Seo konferencia regisztráció</h2>
        
     

        <form id="userForm" action="backend.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Név</label>
                <input type="text" id="name" name="name" placeholder="Nagy Béla" required>
            </div>
            <div class="form-group">
                <label for="birthYear">Születési Év</label>
                <input type="number" id="birthYear" name="birthYear" placeholder="1985" required min="1900" max="2024">
            </div>
            <div class="form-group">
                <label for="email">Email Cím</label>
                <input type="email" id="email" name="email" placeholder="pelda@gmail.com" required>
            </div>
            <div class="form-group">
                <label for="phone">Telefon Szám</label>
                <input type="tel" id="phone" name="phone" placeholder="1234567890" required pattern="[0-9]{11}">
            </div>
            <div class="form-group">
                <label for="workplace">Munkahely</label>
                <input type="text" id="workplace" name="workplace" placeholder="ABC kft." required>
            </div>
            <div class="form-group">
                <label for="position">Munkakör</label>
                <input type="text" id="position" name="position" placeholder="titkár" required>
            </div>
            <div class="form-group">
                <label for="image">Arckép feltöltése</label>
                <input type="file" id="image" name="image" required accept="image/*">
            </div>
            <div class="form-group">
                <label for="captcha">Oldja meg ezt az egyenletet: <?php echo $num1 . "+" . $num2 . "=" ?> </label>
                <input type="hidden" id="correct_captcha" name="correct_captcha" value="<?php echo $sum ?>" required>
                <input type="number" id="captcha" name="captcha" required>
            </div>

            <?php if (!empty($errors)): ?>
            <div class="error-messages">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo '<p style="color:red;">' . $error . '</p>'; ?></p>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <button  type="submit">Elküldés</button>
            </div>

         

        </form>
    </div>
</body>
</html>
